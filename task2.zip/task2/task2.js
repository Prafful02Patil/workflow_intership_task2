


document.getElementById("addToCart").addEventListener("click", function() {
    alert("Product added to cart!");
});
